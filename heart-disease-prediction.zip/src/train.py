import pandas as pd
import joblib
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from src.preprocessing import preprocess_data

# Load data
df = pd.read_csv('data/processed/heart.csv')

# Preprocess
X_scaled, y, scaler = preprocess_data(df)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Train + tune
params = {'n_estimators': [50, 100], 'max_depth': [3, 5, None]}
grid = GridSearchCV(RandomForestClassifier(), params, cv=5)
grid.fit(X_train, y_train)

# Save best model
joblib.dump(grid.best_estimator_, 'models/heart_model.pkl')
print(f"Best model: {grid.best_estimator_}")
