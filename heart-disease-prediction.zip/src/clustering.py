from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import adjusted_rand_score

def perform_hierarchical_clustering(X, y_true):
    model = AgglomerativeClustering(n_clusters=2)
    clusters = model.fit_predict(X)

    ari = adjusted_rand_score(y_true, clusters)
    return clusters, ari
