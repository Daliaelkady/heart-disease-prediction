import streamlit as st
import joblib
import numpy as np

st.title("Heart Disease Predictor")

model = joblib.load("models/heart_model.pkl")

st.sidebar.header("Input Features")
features = []
for name in ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 
             'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']:
    val = st.sidebar.number_input(name, min_value=0.0, step=1.0)
    features.append(val)

if st.button("Predict"):
    prediction = model.predict([features])
    st.success("Prediction: " + ("Heart Disease" if prediction[0] == 1 else "No Heart Disease"))
